`timescale 1ns / 1ps
// 32-bit logical shifter: SLL (is_srl = 0) / SRL (is_srl = 1)
module shifter_32bit (
    input  [31:0] a,
    input  [4:0]  shamt,
    input         is_srl,
    output [31:0] result
);
    assign result = is_srl ? (a >> shamt) : (a << shamt);
endmodule
