`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: alu_1bit
// Project Name: ALU Design (Lab 06)
// Description: 1-bit ALU slice supporting AND, OR, ADD/SUB, XOR
//////////////////////////////////////////////////////////////////////////////////
module alu_1bit (
    input  a,
    input  b,
    input  ainvert,
    input  bnegate,
    input  cin,
    input  [2:0] operation,
    output reg result,
    output cout
);
    wire a_mux = ainvert ? ~a : a;
    wire b_mux = bnegate ? ~b : b;

    wire addsub_out, and_out, or_out, xor_out;

    adder_subtractor addsub_inst (
        .a(a_mux), .b(b), .bnegate(bnegate), .cin(cin),
        .result(addsub_out), .cout(cout)
    );

    and_1bit and_inst (.a(a_mux), .b(b_mux), .result(and_out));
    or_1bit  or_inst  (.a(a_mux), .b(b_mux), .result(or_out));
    xor_1bit xor_inst (.a(a_mux), .b(b_mux), .result(xor_out));

    always @(*) begin
        case (operation)
            3'b000:  result = and_out;
            3'b001:  result = or_out;
            3'b010:  result = addsub_out;
            3'b100:  result = xor_out;
            default: result = 1'b0;
        endcase
    end
endmodule
