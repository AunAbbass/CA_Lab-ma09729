`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: ALU
// Project Name: ALU Design (Lab 06)
// Description: 32-bit ALU built from 32 x alu_1bit slices + 32-bit shifter
//
// ALUControl encoding:
//   0000 ADD | 0001 SUB | 0010 AND | 0011 OR | 0100 XOR | 0101 SLL | 0110 SRL
//////////////////////////////////////////////////////////////////////////////////
module ALU (
    input  [31:0] A,
    input  [31:0] B,
    input  [3:0]  ALUControl,
    output [31:0] ALUResult,
    output        Zero
);
    wire ainvert, bnegate;
    wire [2:0] operation;
    wire is_shift, is_srl;

    wire [31:0] carry;
    wire [31:0] alu_slice_result;
    wire [31:0] shift_result;

    assign ainvert = 1'b0;
    assign bnegate = (ALUControl == 4'b0001);          // SUB

    assign operation = (ALUControl == 4'b0010) ? 3'b000 : // AND
                       (ALUControl == 4'b0011) ? 3'b001 : // OR
                       (ALUControl == 4'b0000) ? 3'b010 : // ADD
                       (ALUControl == 4'b0001) ? 3'b010 : // SUB
                       (ALUControl == 4'b0100) ? 3'b100 : // XOR
                                                 3'b000;

    assign is_shift = (ALUControl == 4'b0101) | (ALUControl == 4'b0110); // SLL / SRL
    assign is_srl   = (ALUControl == 4'b0110);

    // ALU0 (LSB): carry-in = bnegate (adds the +1 for two's complement subtract)
    alu_1bit alu0 (
        .a(A[0]), .b(B[0]),
        .ainvert(ainvert), .bnegate(bnegate),
        .cin(bnegate),
        .operation(operation),
        .result(alu_slice_result[0]),
        .cout(carry[0])
    );

    // ALU1 .. ALU30
    genvar i;
    generate
        for (i = 1; i < 31; i = i + 1) begin : alu_chain
            alu_1bit alu_inst (
                .a(A[i]), .b(B[i]),
                .ainvert(ainvert), .bnegate(bnegate),
                .cin(carry[i-1]),
                .operation(operation),
                .result(alu_slice_result[i]),
                .cout(carry[i])
            );
        end
    endgenerate

    // ALU31 (MSB)
    alu_1bit alu31 (
        .a(A[31]), .b(B[31]),
        .ainvert(ainvert), .bnegate(bnegate),
        .cin(carry[30]),
        .operation(operation),
        .result(alu_slice_result[31]),
        .cout(carry[31])
    );

    shifter_32bit shifter_inst (
        .a(A),
        .shamt(B[4:0]),
        .is_srl(is_srl),
        .result(shift_result)
    );

    assign ALUResult = is_shift ? shift_result : alu_slice_result;
    assign Zero      = (ALUResult == 32'b0);
endmodule
