`timescale 1ns / 1ps
// 1-bit XOR
module xor_1bit (
    input  a,
    input  b,
    output result
);
    assign result = a ^ b;
endmodule
