`timescale 1ns / 1ps
// 1-bit AND
module and_1bit (
    input  a,
    input  b,
    output result
);
    assign result = a & b;
endmodule
