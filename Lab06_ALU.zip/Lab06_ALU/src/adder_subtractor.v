`timescale 1ns / 1ps
// 1-bit full adder / subtractor slice.
// bnegate = 1 -> uses ~b (with cin = 1 on the LSB this gives A - B in two's complement)
module adder_subtractor (
    input  a,
    input  b,
    input  bnegate,
    input  cin,
    output result,
    output cout
);
    wire b_x = b ^ bnegate;
    assign result = a ^ b_x ^ cin;
    assign cout   = (a & b_x) | (cin & (a ^ b_x));
endmodule
