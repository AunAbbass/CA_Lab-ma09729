# Lab 06 – 32-bit ALU (Verilog)

Group: Mohammed Aun Abbas (ma09729), Inshall Abbas (sa11230) | Section T3

## Structure
- `src/` – design files: ALU.v (top), alu_1bit.v, adder_subtractor.v, and_1bit.v, or_1bit.v, xor_1bit.v, shifter_32bit.v
- `sim/ALU_tb.v` – self-checking testbench (directed + shift sweep + 2000 random tests)
- `run_sim.sh` – runs the simulation with Icarus Verilog

## ALUControl encoding
| Code | Op  |
|------|-----|
| 0000 | ADD |
| 0001 | SUB |
| 0010 | AND |
| 0011 | OR  |
| 0100 | XOR |
| 0101 | SLL |
| 0110 | SRL |

## Vivado
Add everything in `src/` as design sources, `sim/ALU_tb.v` as simulation source, set `ALU_tb` as top, Run Behavioral Simulation.
