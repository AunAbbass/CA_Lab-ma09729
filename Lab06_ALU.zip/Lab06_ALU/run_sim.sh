#!/bin/bash
# Run with Icarus Verilog:  ./run_sim.sh
iverilog -g2005 -o alu_sim src/*.v sim/ALU_tb.v && vvp alu_sim
