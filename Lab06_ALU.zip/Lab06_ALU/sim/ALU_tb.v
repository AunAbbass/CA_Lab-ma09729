`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Self-checking testbench for the 32-bit ALU (Lab 06)
//////////////////////////////////////////////////////////////////////////////////
module ALU_tb;
    reg  [31:0] A, B;
    reg  [3:0]  ALUControl;
    wire [31:0] ALUResult;
    wire        Zero;

    integer errors = 0;
    integer tests  = 0;
    integer k;

    ALU dut (.A(A), .B(B), .ALUControl(ALUControl), .ALUResult(ALUResult), .Zero(Zero));

    function [31:0] golden;
        input [31:0] a, b;
        input [3:0]  ctrl;
        begin
            case (ctrl)
                4'b0000: golden = a + b;
                4'b0001: golden = a - b;
                4'b0010: golden = a & b;
                4'b0011: golden = a | b;
                4'b0100: golden = a ^ b;
                4'b0101: golden = a << b[4:0];
                4'b0110: golden = a >> b[4:0];
                default: golden = 32'b0;
            endcase
        end
    endfunction

    task check;
        input [31:0] a, b;
        input [3:0]  ctrl;
        reg   [31:0] exp;
        begin
            A = a; B = b; ALUControl = ctrl;
            #5;
            exp = golden(a, b, ctrl);
            tests = tests + 1;
            if (ALUResult !== exp || Zero !== (exp == 32'b0)) begin
                errors = errors + 1;
                $display("FAIL ctrl=%b A=%h B=%h -> got %h (Z=%b), expected %h (Z=%b)",
                          ctrl, a, b, ALUResult, Zero, exp, (exp == 32'b0));
            end
        end
    endtask

    initial begin
        $dumpfile("ALU_tb.vcd");
        $dumpvars(0, ALU_tb);

        // ---- Directed tests (all 7 operations) ----
        for (k = 0; k < 7; k = k + 1) begin
            check(32'h0000_0000, 32'h0000_0000, k);   // zero flag
            check(32'h0000_0005, 32'h0000_0003, k);
            check(32'h0000_0003, 32'h0000_0005, k);   // negative result on SUB
            check(32'hFFFF_FFFF, 32'h0000_0001, k);   // carry / overflow
            check(32'h7FFF_FFFF, 32'h0000_0001, k);
            check(32'h8000_0000, 32'h0000_0001, k);
            check(32'hAAAA_AAAA, 32'h5555_5555, k);
            check(32'h1234_5678, 32'h1234_5678, k);   // SUB -> zero
            check(32'hDEAD_BEEF, 32'h0000_001F, k);   // max shift
            check(32'hDEAD_BEEF, 32'h0000_0020, k);   // shamt uses B[4:0] only
        end

        // ---- Shift amount sweep ----
        for (k = 0; k < 32; k = k + 1) begin
            check(32'hF0F0_1234, k, 4'b0101);
            check(32'hF0F0_1234, k, 4'b0110);
        end

        // ---- Random tests ----
        for (k = 0; k < 2000; k = k + 1)
            check($random, $random, $urandom % 7);

        $display("--------------------------------------------");
        if (errors == 0) $display("PASS: %0d tests, 0 errors", tests);
        else             $display("FAIL: %0d errors out of %0d tests", errors, tests);
        $display("--------------------------------------------");
        $finish;
    end
endmodule
